package com.examen_Luis_Angel_Glez.Examen.Model;


import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name="thinks")
public class Thinks {
	@Id //Llave primaria de la tabla
	@GeneratedValue(strategy = GenerationType.AUTO) //Se le indica que el campo ID es Autonumerico
	private long id;

	@Column(name = "name")
	private String name;


	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}