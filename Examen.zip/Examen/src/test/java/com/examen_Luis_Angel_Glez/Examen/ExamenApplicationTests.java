package com.examen_Luis_Angel_Glez.Examen;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenApplicationTests {

	@Test
	void contextLoads() {
	}

}
