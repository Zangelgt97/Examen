package com.example.Luis_Angel_Glez_H.Examen2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Examen2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
